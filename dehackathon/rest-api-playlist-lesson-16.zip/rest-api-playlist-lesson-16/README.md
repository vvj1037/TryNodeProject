# rest-api-playlist
Course files for the REST API tutorial series on The Net Ninja Youtube channel

# How to use
Each branch corresponds to a specific lesson in the playlist. For example the lesson-10 branch will contain the code at the END of lesson 10. 

Not every lesson has a corresponding branch (e.g. where the lesson added nothing else to the code).
